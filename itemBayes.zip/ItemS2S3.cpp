#include <RcppArmadillo.h>
#include <limits>
#include <omp.h>

using namespace Rcpp;
using namespace arma;



// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// Choose function
double Choose(int x, int y){
	double result1 = 1, result2 = 1, result;
	int iter = y;
	
    if( x< y ){ result = 0;	}else{	
    for(int i = 0; i<iter; i++){
    	result1 = result1*x;
    	result2 = result2*y;
    	y = y-1;
    	x = x-1;   	
	}	
    	
    	
    result = result1/result2;
	}
return(result);
}




// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// summary function
vec Summary(mat X){

int n = X.n_rows, p = X.n_cols;
int dimension = p + Choose(p,2);
vec result = zeros(dimension);


// S2 
result( span(0, p-1) )=trans( sum(X,0) );

// S3
int ind = p;
for(int k = 1; k< p; k++){
    for(int j = 0; j< k; j++){
        result( ind ) = sum( X.col( k )%X.col( j ) );
        ind = ind + 1;
    }
}


 

return result; 
}


// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// random scan gibbs update
// This is for simulating item response 
mat GibbsX(mat X, vec coef, int cycle){
	
int n = X.n_rows, p = X.n_cols, nums3 = Choose(p,2);
int dimension = p + nums3;

vec changestat = zeros(dimension), Sumstat = Summary(X);



for(int m = 0; m< cycle; m++){
for(int i = 0; i< n; i++){
for(int j = 0; j< p; j++){	
 
    
    // When Xij is 0
    if(X(i,j)==0){ 
            

		//change of s2
		changestat(j) = 1;

		//change of s3
		for(int k = j+1; k< p; k++){  changestat(p+k*(k-1)/2 +j) = (X(i,j)+1)*X(i,k); }
        for(int k = 0; k< j; k++){  changestat(p+j*(j-1)/2 +k ) = (X(i,j)+1)*X(i,k); }  
          

		// accept reject step  	       
		// probability of Xij = 1 for given others are fixed 
        vec r =  exp(trans(coef)*changestat) ;         
        double p = r(0)/(1+r(0));   	 	   
		if( randu() < p  ){
		X(i,j) = 1; 
		Sumstat = Sumstat + changestat;
		}
		changestat = zeros(dimension);
	// When Xij is 1  
    }else{
		
		//change of s2
		changestat(j) = -1;

		//change of s3
		for(int k = j+1; k< p; k++){  changestat(p+k*(k-1)/2 +j ) = -X(i,j)*X(i,k); }  
        for(int k = 0; k< j; k++){  changestat(p+j*(j-1)/2 +k ) = -X(i,j)*X(i,k); }  

		// accept reject step  	       
		// probability of Xij = 1 for given others are fixed 
        vec r =  exp(trans(coef)*changestat) ;         
        double p = r(0)/(1+r(0));   		   
		if( randu() < p  ){
		X(i,j) = 0; 
		Sumstat = Sumstat + changestat;
		}
		changestat = zeros(dimension);			
	}
		
		
}
}	
}
		

return(X); 
}


// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// random scan gibbs update
// This is for simulating item response 
vec Gibbs(mat X, vec coef, int cycle){
	
int n = X.n_rows, p = X.n_cols, nums3 = Choose(p,2);
int dimension = p + nums3;

vec changestat = zeros(dimension), Sumstat = Summary(X);



for(int m = 0; m< cycle; m++){
for(int i = 0; i< n; i++){
for(int j = 0; j< p; j++){	
 
    
    // When Xij is 0
    if(X(i,j)==0){ 
            

		//change of s2
		changestat(j) = 1;

		//change of s3
		for(int k = j+1; k< p; k++){  changestat(p+k*(k-1)/2 +j) = (X(i,j)+1)*X(i,k); }
        for(int k = 0; k< j; k++){  changestat(p+j*(j-1)/2 +k ) = (X(i,j)+1)*X(i,k); }  
          

		// accept reject step  	       
		// probability of Xij = 1 for given others are fixed 
        vec r =  exp(trans(coef)*changestat) ;         
        double p = r(0)/(1+r(0));   	 	   
		if( randu() < p  ){
		X(i,j) = 1; 
		Sumstat = Sumstat + changestat;
		}
		changestat = zeros(dimension);
	// When Xij is 1  
    }else{
		
		//change of s2
		changestat(j) = -1;

		//change of s3
		for(int k = j+1; k< p; k++){  changestat(p+k*(k-1)/2 +j ) = -X(i,j)*X(i,k); }  
        for(int k = 0; k< j; k++){  changestat(p+j*(j-1)/2 +k ) = -X(i,j)*X(i,k); }  

		// accept reject step  	       
		// probability of Xij = 1 for given others are fixed 
        vec r =  exp(trans(coef)*changestat) ;         
        double p = r(0)/(1+r(0));   		   
		if( randu() < p  ){
		X(i,j) = 0; 
		Sumstat = Sumstat + changestat;
		}
		changestat = zeros(dimension);			
	}
		
		
}
}	
}
		

return(Sumstat); 
}





// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// random scan gibbs update
// This is for simulating item response 
vec randomGibbs(mat X, vec coef, int cycle){
	
int n = X.n_rows, p = X.n_cols, nums3 = Choose(p,2);
int dimension = p + nums3;

vec changestat = zeros(dimension), Sumstat = Summary(X);

for(int m = 0; m< cycle; m++){

    int i = ceil(n*randu())-1;   
    int j = ceil(p*randu())-1;  
    
    // When Xij is 0
    if(X(i,j)==0){ 
            

		//change of s2
		changestat(j) = 1;

		//change of s3
		for(int k = j+1; k< p; k++){  changestat(p+k*(k-1)/2 +j) = (X(i,j)+1)*X(i,k); }
        for(int k = 0; k< j; k++){  changestat(p+j*(j-1)/2 +k ) = (X(i,j)+1)*X(i,k); }  
          

		// accept reject step  	       
		// probability of Xij = 1 for given others are fixed 
        vec r =  exp(trans(coef)*changestat) ;         
        double p = r(0)/(1+r(0));   	 	   
		if( randu() < p  ){
		X(i,j) = 1; 
		Sumstat = Sumstat + changestat;
		}
		changestat = zeros(dimension);
	// When Xij is 1  
    }else{
		
		//change of s2
		changestat(j) = -1;

		//change of s3
		for(int k = j+1; k< p; k++){  changestat(p+k*(k-1)/2 +j ) = -X(i,j)*X(i,k); }  
        for(int k = 0; k< j; k++){  changestat(p+j*(j-1)/2 +k ) = -X(i,j)*X(i,k); }  

		// accept reject step  	       
		// probability of Xij = 1 for given others are fixed 
        vec r =  exp(trans(coef)*changestat) ;         
        double p = r(0)/(1+r(0));   		   
		if( randu() < p  ){
		X(i,j) = 0; 
		Sumstat = Sumstat + changestat;
		}
		changestat = zeros(dimension);			
	}
		
		


}
		

return(Sumstat); 
}



// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// random scan gibbs update
vec change(mat X, vec Sumstat,  int i, int j){
	
int n = X.n_rows, p = X.n_cols, nums3 = Choose(p,2);
int dimension = p + nums3;

vec changestat = zeros(dimension);



    // When Xij is 0
    if(X(i,j)==0){ 
            
	
		//change of s2
		changestat(j) = 1;

		//change of s3
		for(int k = j+1; k< p; k++){  changestat(p+k*(k-1)/2 +j) = (X(i,j)+1)*X(i,k); }
        for(int k = 0; k< j; k++){  changestat(p+j*(j-1)/2 +k ) = (X(i,j)+1)*X(i,k); }  
          
		X(i,j) = 1; 
		Sumstat = Sumstat + changestat;


	// When Xij is 1  
    }else{
		
		//change of s2
		changestat(j) = -1;

		//change of s3
		for(int k = j+1; k< p; k++){  changestat(p+k*(k-1)/2 +j ) = -X(i,j)*X(i,k); }  
        for(int k = 0; k< j; k++){  changestat(p+j*(j-1)/2 +k ) = -X(i,j)*X(i,k); }  

		X(i,j) = 0; 
		Sumstat = Sumstat + changestat;
		
	}
		

return(changestat); 
}







// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// Double metropolis hastings algorithm
// one by one update
mat ergmDMH(mat X, vec scale, mat theta, int outer, int cycle){
	
// Initializing part
double logprob,u;                               // used in Outer MCMC
int n = X.n_rows, p = X.n_cols, nums3 = Choose(p,2);
int dimension = p + nums3;                      // number of parameters	
vec stat = Summary(X);                          // sufficient statistics
vec statprop;                          
vec thetaprev(dimension), thetaprop(dimension); // before propose in Outer MCMC, previous parameters
for(int i = 0; i< dimension; i++){ thetaprev[i] = theta(0,i); } 

// indexing 
vec indk = zeros(dimension), indj = zeros(dimension);
for(int k = 1; k< p; k++){ 
for(int j = 0; j< k; j++){
    indk[p+k*(k-1)/2 +j] = k;
     indj[p+k*(k-1)/2 +j] = j;
}
}

//// Start of OUTER MCMC Chain 
for(int l = 0; l< outer-1; l++){

    for(int i = 0; i< dimension; i++){ 
	thetaprop = thetaprev; 
	thetaprop[i] = thetaprev[i] + scale[i]*randn(1)[0];
    
    
    // proposed auxiliary variable		
    statprop = Gibbs(X, thetaprop, cycle);

	// log probability ratio to determine acceptance of Outer MCMC 	
	logprob = -0.05*pow(thetaprop[i],2) + 0.05*pow(thetaprev[i],2) + (thetaprev[i] - thetaprop[i])*(statprop[i] - stat[i]); 
    u = log( randu() );	
    if( u< logprob ){	
    thetaprev[i] = thetaprop[i]; 
	}else{
    thetaprev[i] = thetaprev[i];	
	}	
	
    }

	theta.row(l+1) = trans(thetaprev);	
}
		
	
return(theta);	
}









// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// Double metropolis hastings algorithm
// random scan update 
// one by one update
mat ergmrandomDMH(mat X, vec scale, mat theta, int outer, int cycle){
	
// Initializing part
double logprob,u;                               // used in Outer MCMC
int n = X.n_rows, p = X.n_cols, nums3 = Choose(p,2);
int dimension = p + nums3;                      // number of parameters	
vec stat = Summary(X);                          // sufficient statistics
vec statprop;                          
vec thetaprev(dimension), thetaprop(dimension); // before propose in Outer MCMC, previous parameters
for(int i = 0; i< dimension; i++){ thetaprev[i] = theta(0,i); } 

// indexing 
vec indk = zeros(dimension), indj = zeros(dimension);
for(int k = 1; k< p; k++){ 
for(int j = 0; j< k; j++){
    indk[p+k*(k-1)/2 +j] = k;
     indj[p+k*(k-1)/2 +j] = j;
}
}

//// Start of OUTER MCMC Chain 
for(int l = 0; l< outer-1; l++){

    for(int i = 0; i< dimension; i++){ 
	thetaprop = thetaprev; 
	thetaprop[i] = thetaprev[i] + scale[i]*randn(1)[0];
    
    
    // proposed auxiliary variable		
    statprop = randomGibbs(X, thetaprop, cycle);

	// log probability ratio to determine acceptance of Outer MCMC 	
	logprob = -0.05*pow(thetaprop[i],2) + 0.05*pow(thetaprev[i],2) + (thetaprev[i] - thetaprop[i])*(statprop[i] - stat[i]); 
    u = log( randu() );	
    if( u< logprob ){	
    thetaprev[i] = thetaprop[i]; 
	}else{
    thetaprev[i] = thetaprev[i];	
	}	
	
    }

	theta.row(l+1) = trans(thetaprev);	
}
		
	
return(theta);	
}






// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// spike slab normal prior 
// log scale
double spikeNorm(double theta, double lambda, double sigmasq, double w){
 	
double res = log(   lambda*(1/sqrt(2*(M_PI)*sigmasq*pow(w,2))*exp( -pow(theta,2)/(2*sigmasq*pow(w,2)) ))  + (1-lambda)*(1/sqrt(2*(M_PI)*sigmasq)*exp( -pow(theta,2)/(2*sigmasq) ))   );

return(res);	
}





// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// Double metropolis hastings algorithm
// one by one update
// random scan update 
// Spike slab prior
// w and sigma2 only one 
List ergmrandomDMHvarNotransform(mat X, vec scale, double sigscale, double wscale, mat theta, mat para, int outer, int cycle){
	
// Initializing part
double logprob,u,negativeInf = -std::numeric_limits<float>::infinity();;     // used in Outer MCMC
int n = X.n_rows, p = X.n_cols, nums3 = Choose(p,2);
int dimension = p + nums3;                                                   // number of parameters	
vec stat = Summary(X);                                                       // sufficient statistics
vec statprop;                          
vec thetaprev(dimension), thetaprop(dimension);                              // before propose in Outer MCMC, previous parameters
for(int i = 0; i< dimension; i++){ thetaprev[i] = theta(0,i); } 

vec lambda(dimension);   // lambda
double sigmasq;  //sigmasq
double w;        //w   

for(int i = 0; i< dimension; i++){  lambda[i] = para(0,i);  }

sigmasq = para(0,dimension);
w = para(0,dimension+1);




//// Start of OUTER MCMC Chain 
for(int l = 0; l< outer-1; l++){

    for(int i = 0; i< dimension; i++){ 
    
    //// ERGM parameter updates
	thetaprop = thetaprev; 
	thetaprop[i] = thetaprev[i] + scale[i]*randn(1)[0];
    
    // proposed auxiliary variable		
    statprop = randomGibbs(X, thetaprop, cycle);
		
	// log probability ratio to determine acceptance of Outer MCMC 	
	logprob = spikeNorm(thetaprop[i], lambda[i], sigmasq, w) - spikeNorm(thetaprev[i], lambda[i], sigmasq, w) + (thetaprev[i] - thetaprop[i])*(statprop[i] - stat[i]); 
    u = log( randu() );	
    if( u< logprob ){	
    thetaprev[i] = thetaprop[i]; 
	}else{
    thetaprev[i] = thetaprev[i];	
	}	
	
	
	//// lambda updates 
    double loga = spikeNorm(thetaprev[i], 1, sigmasq, w);
    double logb = spikeNorm(thetaprev[i], 0, sigmasq, w);
    double lambdaprob = exp(loga)/(exp(loga) + exp(logb));	
    double r = randu();    	
    if( r < lambdaprob ){
    lambda[i] = 1;	
	}else{
    lambda[i] = 0;	
	}

    }

	//// sigmasq updates
	double sigmasqprop = sigmasq + sigscale*randn(1)[0];
	double logsigmasqprob = 0;
		
    if( sigmasqprop > 0.25 || sigmasqprop < 0.01 ){ logsigmasqprob = negativeInf;	
	}else{
	for(int i = 0; i< dimension; i++){  logsigmasqprob = logsigmasqprob + spikeNorm(thetaprev[i], lambda[i], sigmasqprop, w) -  spikeNorm(thetaprev[i], lambda[i], sigmasq, w);   }
    logsigmasqprob = logsigmasqprob - 2*log(sigmasqprop) + 2*log(sigmasq);
    }

    double	r = log( randu() );
    if( r< logsigmasqprob ){
    sigmasq = sigmasqprop;	
	}else{
    sigmasq = sigmasq;	
	}
	

	
	//// w updates
	double wprop = w + wscale*randn(1)[0];
	double logwprob = 0; 
	
    if( wprop < 1 ){ logwprob = negativeInf;	
	}else{	
	for(int i = 0; i< dimension; i++){ logwprob = logwprob + spikeNorm(thetaprev[i], lambda[i], sigmasq, wprop) -  spikeNorm(thetaprev[i], lambda[i], sigmasq, w); }
    logwprob = logwprob + log(0.01) - 0.01*(wprop-1) -  log(0.01) + 0.01*(w-1);
    }
    
	r = log( randu() );
    if( r< logwprob ){
    w = wprop;	
	}else{
    w = w;	
	}	

    
	theta.row(l+1) = trans(thetaprev);		
	for(int i = 0; i< dimension; i++){ para(l+1,i) = lambda[i]; }
    para(l+1,dimension) = sigmasq;	
    para(l+1,dimension+1) = w;
	
	
	
}
		
	
		
return List::create(Named("theta") = theta, Named("para") = para); 
}









// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// Double metropolis hastings algorithm
// one by one update
// random scan update 
// Spike slab prior
// w and sigma2 only one
// w and sigma2 are log scaled 
List ergmrandomDMHvar(mat X, vec scale, double sigscale, double wscale, mat theta, mat para, int outer, int cycle){
	
// Initializing part
double logprob,u,negativeInf = -std::numeric_limits<float>::infinity();;     // used in Outer MCMC
int n = X.n_rows, p = X.n_cols, nums3 = Choose(p,2);
int dimension = p + nums3;                                                   // number of parameters	
vec stat = Summary(X);                                                       // sufficient statistics
vec statprop;                          
vec thetaprev(dimension), thetaprop(dimension);                              // before propose in Outer MCMC, previous parameters
for(int i = 0; i< dimension; i++){ thetaprev[i] = theta(0,i); } 

vec lambda(dimension);   // lambda
double sigmasq;  //logscale sigmasq 
double w;        //logscale w   

for(int i = 0; i< dimension; i++){  lambda[i] = para(0,i);  }

sigmasq = para(0,dimension);
w = para(0,dimension+1);




//// Start of OUTER MCMC Chain 
for(int l = 0; l< outer-1; l++){

    for(int i = 0; i< dimension; i++){ 
    
    //// ERGM parameter updates
	thetaprop = thetaprev; 
	thetaprop[i] = thetaprev[i] + scale[i]*randn(1)[0];
    
    // proposed auxiliary variable		
    statprop = randomGibbs(X, thetaprop, cycle);
		
	// log probability ratio to determine acceptance of Outer MCMC 	
	logprob = spikeNorm(thetaprop[i], lambda[i], exp(sigmasq), exp(w)) - spikeNorm(thetaprev[i], lambda[i], exp(sigmasq), exp(w)) + (thetaprev[i] - thetaprop[i])*(statprop[i] - stat[i]); 
    u = log( randu() );	
    if( u< logprob ){	
    thetaprev[i] = thetaprop[i]; 
	}else{
    thetaprev[i] = thetaprev[i];	
	}	
	
	
	//// lambda updates 
    double loga = spikeNorm(thetaprev[i], 1, exp(sigmasq), exp(w));
    double logb = spikeNorm(thetaprev[i], 0, exp(sigmasq), exp(w));
    double lambdaprob = exp(loga)/(exp(loga) + exp(logb));	
    double r = randu();    	
    if( r < lambdaprob ){
    lambda[i] = 1;	
	}else{
    lambda[i] = 0;	
	}

    }


	//// sigmasq updates
	double sigmasqprop = sigmasq + sigscale*randn(1)[0];
	double logsigmasqprob = 0;
    if( exp(sigmasqprop) > 0.25 || exp(sigmasqprop) < 0.01 ){ logsigmasqprob = negativeInf;	
	}else{		
	for(int i = 0; i< dimension; i++){  logsigmasqprob = logsigmasqprob + spikeNorm(thetaprev[i], lambda[i], exp(sigmasqprop), exp(w)) -  spikeNorm(thetaprev[i], lambda[i], exp(sigmasq), exp(w));   }
    logsigmasqprob = logsigmasqprob - sigmasqprop +  sigmasq;
    }
    
    double	r = log( randu() );
    if( r< logsigmasqprob ){
    sigmasq = sigmasqprop;	
	}else{
    sigmasq = sigmasq;	
	}
	

	

	//// w updates
	double wprop = w + wscale*randn(1)[0];
	double logwprob = 0; 
	
    if( exp(wprop) < 1 ){ logwprob = negativeInf;	
	}else{	
	for(int i = 0; i< dimension; i++){ logwprob = logwprob + spikeNorm(thetaprev[i], lambda[i], exp(sigmasq), exp(wprop)) -  spikeNorm(thetaprev[i], lambda[i], exp(sigmasq), exp(w)); }
    logwprob = logwprob + wprop + log(0.01) - 0.01*(exp(wprop)-1) -  wprop - log(0.01) + 0.01*(exp(w)-1);
    }
    
	r = log( randu() );
    if( r< logwprob ){
    w = wprop;	
	}else{
    w = w;	
	}	

    
	theta.row(l+1) = trans(thetaprev);		
	for(int i = 0; i< dimension; i++){ para(l+1,i) = lambda[i]; }
    para(l+1,dimension) = sigmasq;	
    para(l+1,dimension+1) = w;
	
	
	
}
		
	
		
return List::create(Named("theta") = theta, Named("para") = para); 
}






















