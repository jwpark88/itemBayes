rm(list=ls())

library(rstudioapi)
current_path <-rstudioapi::getActiveDocumentContext()$path
setwd(dirname(current_path))

library(statnet)
load("AbortionGOF.RData")

nsamp = nrow(X)
nitem = ncol(X)
niter = 1000
origin.y = array(0,dim=c(nsamp,nitem,nitem))
bayes.y = list()
lasso.y = list()

for(k in 1:nsamp){
  for(i in 2:nitem){
    for(j in 1:(i-1)){
      origin.y[k,i,j] = X[k,i] * X[k,j]
      origin.y[k,j,i] = origin.y[k,i,j]
    }
  }
}

for(iter in 1:niter){
  bayes.y.array = array(0,dim=c(nsamp,nitem,nitem))
  lasso.y.array = array(0,dim=c(nsamp,nitem,nitem))
  
  for(k in 1:nsamp){
    for(i in 2:nitem){
      for(j in 1:(i-1)){
        bayes.y.array[k,i,j] = simul.bayes[iter,k,i] * simul.bayes[iter,k,j]
        bayes.y.array[k,j,i] = bayes.y.array[k,i,j]
        lasso.y.array[k,i,j] = simul.elasso[iter,k,i] * simul.elasso[iter,k,j]
        lasso.y.array[k,j,i] = lasso.y.array[k,i,j]
      }
    }
  }
  
  bayes.y[[iter]] = bayes.y.array
  lasso.y[[iter]] = lasso.y.array
}

origin.deg = matrix(NA,nsamp,nitem)
origin.esp = matrix(NA,nsamp,nitem-1)
for(k in 1:nsamp){
  origin.net = as.network.matrix(origin.y[k,,],directed=FALSE)
  origin.deg[k,] = summary(origin.net~degree(0:(nitem-1)))
  origin.esp[k,] = summary(origin.net~esp(0:(nitem-2)))
}
origin.deg.sum = colSums(origin.deg)
origin.esp.sum = colSums(origin.esp)

bayes.deg = array(NA,dim=c(niter,nsamp,nitem))
bayes.esp = array(NA,dim=c(niter,nsamp,(nitem-1)))
lasso.deg = array(NA,dim=c(niter,nsamp,nitem))
lasso.esp = array(NA,dim=c(niter,nsamp,(nitem-1)))

bayes.deg.sum = matrix(NA,niter,nitem)
bayes.esp.sum = matrix(NA,niter,(nitem-1))
lasso.deg.sum = matrix(NA,niter,nitem)
lasso.esp.sum = matrix(NA,niter,(nitem-1))

for(iter in 1:niter){
  for(k in 1:nsamp){
    bayes.net = as.network.matrix(bayes.y[[iter]][k,,],directed=FALSE)
    lasso.net = as.network.matrix(lasso.y[[iter]][k,,],directed=FALSE)
    bayes.deg[iter,k,] = summary(bayes.net~degree(0:(nitem-1)))
    lasso.deg[iter,k,] = summary(lasso.net~degree(0:(nitem-1)))
    bayes.esp[iter,k,] = summary(bayes.net~esp(0:(nitem-2)))
    lasso.esp[iter,k,] = summary(lasso.net~esp(0:(nitem-2)))
  }
  for(i in 1:nitem){
    bayes.deg.sum[iter,i] = sum(bayes.deg[iter,,i])
    lasso.deg.sum[iter,i] = sum(lasso.deg[iter,,i])
  }
  for(i in 1:(nitem-1)){
    bayes.esp.sum[iter,i] = sum(bayes.esp[iter,,i])
    lasso.esp.sum[iter,i] = sum(lasso.esp[iter,,i])
  }
  print(iter)
}

pdf("abortion_bayes_degree_gof.pdf")
ymax = max(bayes.deg.sum/nsamp,origin.deg.sum/nsamp)
boxplot(bayes.deg.sum[,1:nitem]/nsamp,ylim=c(0,ymax+0.1),xaxt="n",main="Bayes GOF (degree)",cex=0.5)
points(origin.deg.sum/nsamp,pch=19,col=2)
lines(origin.deg.sum/nsamp,lwd=2,col=2)
x_axis_tick = seq(0,nitem-1,by=1)
axis(side=1,at=1:nitem,labels=x_axis_tick)
dev.off()

pdf("abortion_lasso_degree_gof.pdf")
ymax = max(lasso.deg.sum/nsamp,origin.deg.sum/nsamp)
boxplot(lasso.deg.sum[,1:nitem]/nsamp,ylim=c(0,ymax+0.1),xaxt="n",main="eLasso GOF (degree)",cex=0.5)
points(origin.deg.sum/nsamp,pch=19,col=2)
lines(origin.deg.sum/nsamp,lwd=2,col=2)
x_axis_tick = seq(0,nitem-1,by=1)
axis(side=1,at=1:nitem,labels=x_axis_tick)
dev.off()

pdf("abortion_bayes_esp_gof.pdf")
ymax = max(bayes.esp.sum/nsamp,origin.esp.sum/nsamp)
boxplot(bayes.esp.sum[,1:(nitem-1)]/nsamp,ylim=c(0,ymax+0.1),xaxt="n",main="Bayes GOF (ESP)",cex=0.5)
points(origin.esp.sum/nsamp,pch=19,col=2)
lines(origin.esp.sum/nsamp,lwd=2,col=2)
x_axis_tick = seq(0,nitem-2,by=1)
axis(side=1,at=1:(nitem-1),labels=x_axis_tick)
dev.off()

pdf("abortion_lasso_esp_gof.pdf")
ymax = max(lasso.esp.sum/nsamp,origin.esp.sum/nsamp)
boxplot(lasso.esp.sum[,1:(nitem-1)]/nsamp,ylim=c(0,ymax+0.1),xaxt="n",main="eLasso GOF (ESP)",cex=0.5)
points(origin.esp.sum/nsamp,pch=19,col=2)
lines(origin.esp.sum/nsamp,lwd=2,col=2)
x_axis_tick = seq(0,nitem-2,by=1)
axis(side=1,at=1:(nitem-1),labels=x_axis_tick)
dev.off()

pdf("abortion_high_order_gof.pdf")
par(mfrow=c(2,2))
ymax = 3.9
boxplot(lasso.deg.sum[,1:nitem]/nsamp,ylim=c(0,ymax+0.1),xaxt="n",main="eLasso GOF (degree)",cex=0.5)
points(origin.deg.sum/nsamp,pch=19,col=2)
lines(origin.deg.sum/nsamp,lwd=2,col=2)
x_axis_tick = seq(0,nitem-1,by=1)
axis(side=1,at=1:nitem,labels=x_axis_tick)

boxplot(bayes.deg.sum[,1:nitem]/nsamp,ylim=c(0,ymax+0.1),xaxt="n",main="Bayes GOF (degree)",cex=0.5)
points(origin.deg.sum/nsamp,pch=19,col=2)
lines(origin.deg.sum/nsamp,lwd=2,col=2)
x_axis_tick = seq(0,nitem-1,by=1)
axis(side=1,at=1:nitem,labels=x_axis_tick)

ymax = 8.9
boxplot(lasso.esp.sum[,1:(nitem-1)]/nsamp,ylim=c(0,ymax+0.1),xaxt="n",main="eLasso GOF (ESP)",cex=0.5)
points(origin.esp.sum/nsamp,pch=19,col=2)
lines(origin.esp.sum/nsamp,lwd=2,col=2)
x_axis_tick = seq(0,nitem-2,by=1)
axis(side=1,at=1:(nitem-1),labels=x_axis_tick)

boxplot(bayes.esp.sum[,1:(nitem-1)]/nsamp,ylim=c(0,ymax+0.1),xaxt="n",main="Bayes GOF (ESP)",cex=0.5)
points(origin.esp.sum/nsamp,pch=19,col=2)
lines(origin.esp.sum/nsamp,lwd=2,col=2)
x_axis_tick = seq(0,nitem-2,by=1)
axis(side=1,at=1:(nitem-1),labels=x_axis_tick)
dev.off()

save.image("abortion_high_order_gof.RData")

load("abortion_high_order_gof.RData")
origin.cli = matrix(0,nsamp,nitem)
for(k in 1:nsamp){
  origin.net = as.network.matrix(origin.y[k,,],directed=FALSE)
  origin.tmp = clique.census(origin.net)$clique.count[,1]
  origin.cli[k,1:length(origin.tmp)] = origin.tmp
}
origin.cli.sum = colSums(origin.cli)

bayes.cli = array(0,dim=c(niter,nsamp,nitem))
lasso.cli = array(0,dim=c(niter,nsamp,nitem))

bayes.cli.sum = matrix(0,niter,nitem)
lasso.cli.sum = matrix(0,niter,nitem)

for(iter in 1:niter){
  for(k in 1:nsamp){
    bayes.net = as.network.matrix(bayes.y[[iter]][k,,],directed=FALSE)
    lasso.net = as.network.matrix(lasso.y[[iter]][k,,],directed=FALSE)
    bayes.tmp = clique.census(bayes.net)$clique.count[,1]
    lasso.tmp = clique.census(lasso.net)$clique.count[,1]
    bayes.cli[iter,k,1:length(bayes.tmp)] = bayes.tmp
    lasso.cli[iter,k,1:length(lasso.tmp)] = lasso.tmp
  }
  for(i in 1:nitem){
    bayes.cli.sum[iter,i] = sum(bayes.cli[iter,,i])
    lasso.cli.sum[iter,i] = sum(lasso.cli[iter,,i])
  }
  print(iter)
}

rmse.bayes.cli.sum = bayes.cli.sum
rmse.lasso.cli.sum = lasso.cli.sum
for(iter in 1:niter){
  rmse.bayes.cli.sum[iter,] = rmse.bayes.cli.sum[iter,]/nsamp - origin.cli.sum/nsamp
  rmse.lasso.cli.sum[iter,] = rmse.lasso.cli.sum[iter,]/nsamp - origin.cli.sum/nsamp
}
rmse.bayes.cli.sum = rmse.bayes.cli.sum^2
rmse.lasso.cli.sum = rmse.lasso.cli.sum^2
round(sqrt(colMeans(rmse.bayes.cli.sum)),4)
round(sqrt(colMeans(rmse.lasso.cli.sum)),4)
# [1] 0.3126 0.0157 0.0565 0.0279 0.0257 0.0441 0.0956
# [1] 0.2489 0.0100 0.0367 0.0320 0.0182 0.0436 0.1118

mad.bayes.cli.sum = bayes.cli.sum
mad.lasso.cli.sum = lasso.cli.sum
for(iter in 1:niter){
  mad.bayes.cli.sum[iter,] = abs(mad.bayes.cli.sum[iter,]/nsamp - origin.cli.sum/nsamp)
  mad.lasso.cli.sum[iter,] = abs(mad.lasso.cli.sum[iter,]/nsamp - origin.cli.sum/nsamp)
}
round(colMeans(mad.bayes.cli.sum),4)
round(colMeans(mad.lasso.cli.sum),4)
# [1] 0.2170 0.0113 0.0423 0.0198 0.0210 0.0382 0.0730
# [1] 0.2438 0.0079 0.0336 0.0289 0.0148 0.0414 0.1110

pdf("abortion_bayes_clique_gof.pdf")
ymax = log(max(bayes.cli.sum/nsamp,origin.cli.sum/nsamp))
boxplot(log(bayes.cli.sum[,1:nitem]/nsamp),ylim=c(-4.0,ymax+0.1),xaxt="n",ylab="log(count)",main="Bayes GOF (clique)",cex=0.5)
points(log(origin.cli.sum/nsamp),pch=19,col=2)
lines(log(origin.cli.sum/nsamp),lwd=2,col=2)
x_axis_tick = seq(1,nitem,by=1)
axis(side=1,at=1:nitem,labels=x_axis_tick)
dev.off()

pdf("abortion_lasso_clique_gof.pdf")
ymax = log(max(lasso.cli.sum/nsamp,origin.cli.sum/nsamp))
boxplot(log(lasso.cli.sum[,1:nitem]/nsamp),ylim=c(-4.0,ymax+0.1),xaxt="n",ylab="log(count)",main="eLasso GOF (clique)",cex=0.5)
points(log(origin.cli.sum/nsamp),pch=19,col=2)
lines(log(origin.cli.sum/nsamp),lwd=2,col=2)
x_axis_tick = seq(1,nitem,by=1)
axis(side=1,at=1:nitem,labels=x_axis_tick)
dev.off()

pdf("abortion_clique_gof.pdf")
par(mfrow=c(1,2))
ymax = max(bayes.cli.sum/nsamp,origin.cli.sum/nsamp)
boxplot(bayes.cli.sum[,1:nitem]/nsamp,ylim=c(0,ymax+0.1),xaxt="n",ylab="mean count",main="Bayes GOF (clique)",cex=0.5)
points(origin.cli.sum/nsamp,pch=19,col=2)
lines(origin.cli.sum/nsamp,lwd=2,col=2)
x_axis_tick = seq(1,nitem,by=1)
axis(side=1,at=1:nitem,labels=x_axis_tick)

ymax = max(bayes.cli.sum/nsamp,origin.cli.sum/nsamp)
boxplot(lasso.cli.sum[,1:nitem]/nsamp,ylim=c(0,ymax+0.1),xaxt="n",ylab="mean count",main="eLasso GOF (clique)",cex=0.5)
points(origin.cli.sum/nsamp,pch=19,col=2)
lines(origin.cli.sum/nsamp,lwd=2,col=2)
x_axis_tick = seq(1,nitem,by=1)
axis(side=1,at=1:nitem,labels=x_axis_tick)
dev.off()

pdf("abortion_log_clique_gof.pdf")
par(mfrow=c(1,2))
ymax = log(max(bayes.cli.sum/nsamp,origin.cli.sum/nsamp))
boxplot(log(bayes.cli.sum[,1:nitem]/nsamp),ylim=c(-4.0,ymax+0.1),xaxt="n",ylab="log(mean count)",main="Bayes GOF (clique)",cex=0.5)
points(log(origin.cli.sum/nsamp),pch=19,col=2)
lines(log(origin.cli.sum/nsamp),lwd=2,col=2)
x_axis_tick = seq(1,nitem,by=1)
axis(side=1,at=1:nitem,labels=x_axis_tick)

ymax = log(max(bayes.cli.sum/nsamp,origin.cli.sum/nsamp))
boxplot(log(lasso.cli.sum[,1:nitem]/nsamp),ylim=c(-4.0,ymax+0.1),xaxt="n",ylab="log(mean count)",main="eLasso GOF (clique)",cex=0.5)
points(log(origin.cli.sum/nsamp),pch=19,col=2)
lines(log(origin.cli.sum/nsamp),lwd=2,col=2)
x_axis_tick = seq(1,nitem,by=1)
axis(side=1,at=1:nitem,labels=x_axis_tick)
dev.off()

save.image("abortion_high_order_cliqe_gof.RData")
